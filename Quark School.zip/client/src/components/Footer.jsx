//client/src/components/Footer.jsx
import React from "react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const footerSections = [
    {
      title: "Quark School",
      subtitle: "The Building Blocks",
      description: "Empowering futures with international education.",
      type: "brand",
    },
    {
      title: "Academics",
      items: ["Pre Primary"],
      type: "links",
    },
    {
      title: "Resources",
      items: [
        "Sports Day",
        "Winter Celebration",
        "Activity Day",
        "Award Ceremony",
      ],
      type: "links",
    },
    {
      title: "Contact Info",
      items: [
        {
          icon: "📞",
          text: "+92 335 5114051",
          link: "tel:+923355114051",
          ariaLabel: "Call us at +92 335 5114051",
        },
        {
          icon: "✉️",
          text: "Quarkschool.edu@gmail.com",
          link: "mailto:Quarkschool.edu@gmail.com",
          ariaLabel: "Send email to Quarkschool.edu@gmail.com",
        },
      ],
      type: "contact",
    },
  ];

  const socialLinks = [
    {
      name: "Facebook",
      url: "https://www.facebook.com/share/1BTg9anMDv/",
      ariaLabel: "Visit our Facebook page",
      icon: (
        <div className="w-6 h-6 rounded-lg bg-white flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
          <svg
            className="w-4 h-4"
            fill="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
          </svg>
        </div>
      ),
    },
    {
      name: "Instagram",
      url: "https://www.instagram.com/quark.school?igsh=MXJtdHVnYjI2cDdxMg==",
      ariaLabel: "Visit our Instagram page",
      icon: (
        <div className="w-6 h-6 rounded-lg bg-pink-100 flex items-center justify-center text-pink-600 group-hover:bg-pink-600 group-hover:text-white transition-all duration-300">
          <svg
            className="w-4 h-4"
            fill="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            <path d="M7.75 2h8.5A5.75 5.75 0 0122 7.75v8.5A5.75 5.75 0 0116.25 22h-8.5A5.75 5.75 0 012 16.25v-8.5A5.75 5.75 0 017.75 2zm0 1.5A4.25 4.25 0 003.5 7.75v8.5A4.25 4.25 0 007.75 20.5h8.5a4.25 4.25 0 004.25-4.25v-8.5A4.25 4.25 0 0016.25 3.5h-8.5zM12 7a5 5 0 110 10 5 5 0 010-10zm0 1.5a3.5 3.5 0 100 7 3.5 3.5 0 000-7zm5.25-.88a1.13 1.13 0 110 2.25 1.13 1.13 0 010-2.25z" />
          </svg>
        </div>
      ),
    },
  ];

  return (
    <footer className="relative mt-20" role="contentinfo">
      {/* Top gradient line */}
      <div
        className="h-0.5 w-full"
        style={{
          background: "linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%)",
        }}
      />

      <div
        className="relative"
        style={{
          background: "linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)", // Safari support
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {footerSections.map((section, index) => (
              <div key={index} className="text-center md:text-left">
                {section.type === "brand" ? (
                  <div className="space-y-4">
                    <div>
                      <h3
                        className="text-2xl font-black mb-2"
                        style={{
                          fontFamily: "Poppins, sans-serif",
                          background:
                            "linear-gradient(135deg, #1e293b 0%, #3b82f6 100%)",
                          WebkitBackgroundClip: "text",
                          WebkitTextFillColor: "transparent",
                          backgroundClip: "text",
                        }}
                      >
                        {section.title}
                      </h3>
                      <p className="text-sm font-semibold text-gray-500 mb-3">
                        {section.subtitle}
                      </p>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        {section.description}
                      </p>
                    </div>

                    {/* Social Links */}
                    <div className="flex justify-center md:justify-start space-x-4 pt-4">
                      <h4 className="sr-only">Follow us on social media</h4>
                      {socialLinks.map((social, socialIndex) => (
                        <a
                          key={socialIndex}
                          href={social.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="group relative p-3 rounded-xl transition-all duration-300 transform hover:scale-110 hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                          style={{
                            background: "rgba(59, 130, 246, 0.1)",
                            color: "#3b82f6",
                          }}
                          aria-label={social.ariaLabel}
                          onMouseEnter={(e) => {
                            const target = e.currentTarget;
                            target.style.background =
                              "linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%)";
                            target.style.color = "#ffffff";
                            target.style.boxShadow =
                              "0 8px 25px rgba(59, 130, 246, 0.3)";
                          }}
                          onMouseLeave={(e) => {
                            const target = e.currentTarget;
                            target.style.background =
                              "rgba(59, 130, 246, 0.1)";
                            target.style.color = "#3b82f6";
                            target.style.boxShadow = "none";
                          }}
                        >
                          {social.icon}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div>
                    <h4
                      className="text-lg font-bold mb-6"
                      style={{
                        fontFamily: "Poppins, sans-serif",
                        color: "#1e293b",
                      }}
                    >
                      {section.title}
                    </h4>

                    {section.type === "contact" ? (
                      <div className="space-y-4">
                        <address className="not-italic">
                          {section.items.map((item, itemIndex) => (
                            <div key={itemIndex} className="mb-4">
                              <a
                                href={item.link}
                                className="group flex items-center justify-center md:justify-start text-gray-600 hover:text-blue-600 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-md p-1"
                                aria-label={item.ariaLabel}
                              >
                                <span 
                                  className="mr-3 text-lg group-hover:scale-110 transition-transform duration-300"
                                  aria-hidden="true"
                                >
                                  {item.icon}
                                </span>
                                <span className="group-hover:translate-x-1 transition-transform duration-300">
                                  {item.text}
                                </span>
                              </a>
                            </div>
                          ))}
                        </address>

                        <div className="pt-4">
                          <p className="text-sm font-semibold text-gray-700 mb-2">
                            For Any Query
                          </p>
                          <p className="text-sm text-gray-500">
                            Email us for assistance.
                          </p>
                        </div>
                      </div>
                    ) : (
                      <nav aria-label={`${section.title} navigation`}>
                        <ul className="space-y-3">
                          {section.items.map((item, itemIndex) => (
                            <li key={itemIndex}>
                              <button
                                type="button"
                                onClick={() => {
                                  // Add navigation logic here when pages are available
                                  console.log(`Navigate to ${item}`);
                                }}
                                className="text-gray-600 hover:text-blue-600 transition-all duration-300 hover:translate-x-1 transform inline-block text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-md p-1 cursor-pointer"
                                aria-label={`Learn more about ${item}`}
                              >
                                {item}
                              </button>
                            </li>
                          ))}
                        </ul>
                      </nav>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Bottom Section */}
          <div
            className="mt-16 pt-8 border-t text-center"
            style={{ borderColor: "rgba(59, 130, 246, 0.1)" }}
          >
            <p className="text-sm text-gray-500">
              © {currentYear} Quark School. All rights reserved. | Empowering
              futures through quality education.
            </p>
          </div>
        </div>

        {/* Decorative Background Pattern */}
        <div
          className="absolute inset-0 opacity-5 pointer-events-none"
          style={{
            backgroundImage: `
              radial-gradient(circle at 20% 80%, rgba(59, 130, 246, 0.3) 0%, transparent 50%),
              radial-gradient(circle at 80% 20%, rgba(148, 163, 184, 0.3) 0%, transparent 50%)
            `,
          }}
          aria-hidden="true"
        />
      </div>
    </footer>
  );
}